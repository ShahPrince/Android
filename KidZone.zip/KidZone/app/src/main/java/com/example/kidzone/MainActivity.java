package com.example.kidzone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {
    Button alphabets,shapes,colours,flowers,vegetables,fruits;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        alphabets = (Button) findViewById(R.id.alphabets);
        shapes = (Button) findViewById(R.id.shapes);
        colours = (Button) findViewById(R.id.colours);
        flowers = (Button) findViewById(R.id.flowers);
        vegetables = (Button) findViewById(R.id.vegetables);
        fruits = (Button) findViewById(R.id.fruits);


        alphabets.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v){
                Intent i = new Intent(getApplicationContext(), Activity2.class);
                i.putExtra("type","alphabets");
                i.putExtra("color","#B6DAF7");
                startActivity(i);

            }
        });
        shapes.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Activity2.class);
                i.putExtra("type","shapes");
                i.putExtra("color","#F8A0BE");
                startActivity(i);
            }
        });
        colours.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Activity2.class);
                i.putExtra("type","colours");
                i.putExtra("color","#81F086");
                startActivity(i);
            }
        });
        flowers.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Activity2.class);
                i.putExtra("type","flowers");
                i.putExtra("color","#F79E83");
                startActivity(i);
            }
        });
        vegetables.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Activity2.class);
                i.putExtra("type","vegetables");
                i.putExtra("color","#858BF7");
                startActivity(i);
            }
        });
        fruits.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Activity2.class);
                i.putExtra("type","fruits");
                i.putExtra("color","#FDEF75");
                startActivity(i);
            }
        });



    }
}