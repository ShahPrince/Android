package com.example.kidzone;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Activity2 extends AppCompatActivity {
    ImageView image1;
    TextView heading;
    String type,headingcolor;
    Button previous,next;
    int headingbackground;
    int[] abc = new int[]{R.drawable.a,R.drawable.b,R.drawable.c,R.drawable.d,R.drawable.e,R.drawable.f,R.drawable.g,R.drawable.h,R.drawable.i,R.drawable.j,R.drawable.k,R.drawable.l,R.drawable.m,R.drawable.n,R.drawable.o,R.drawable.p,R.drawable.q,R.drawable.r,R.drawable.s,R.drawable.t,R.drawable.u,R.drawable.v,R.drawable.w,R.drawable.x,R.drawable.y,R.drawable.z};
    int[] shapes = new int[]{R.drawable.s1,R.drawable.s2,R.drawable.s3,R.drawable.s4,R.drawable.s5};
    int[] colours = new int[]{R.drawable.color1,R.drawable.color2,R.drawable.color3,R.drawable.color4,R.drawable.color5};
    int[] flowers = new int[]{R.drawable.f1,R.drawable.f2,R.drawable.f3,R.drawable.f4,R.drawable.f5};
    int[] vegs = new int[]{R.drawable.v1,R.drawable.v2,R.drawable.v3,R.drawable.v4,R.drawable.v5};
    int[] fruits = new int[]{R.drawable.fruit1,R.drawable.fruit2,R.drawable.fruit3,R.drawable.fruit4,R.drawable.fruit5,R.drawable.fruit6};

    int n =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        image1=(ImageView)findViewById(R.id.p1);
        previous = (Button) findViewById(R.id.prev);
        next = (Button) findViewById(R.id.next);
        heading  = (TextView) findViewById(R.id.heading);

        type = getIntent().getStringExtra("type");
        headingcolor = getIntent().getStringExtra("color");

        headingbackground = Color.parseColor(headingcolor);
        heading.setText(type);
        heading.setBackgroundColor(headingbackground);

        if(type.equals("alphabets"))
        {
            image1.setImageResource(abc[n]);

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    if(n<abc.length-1)
                    {
                        image1.setImageResource(abc[++n]);
                    }
                    else
                    {
                        n=0;
                        image1.setImageResource(abc[n]);
                    }

                }
            });

            previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (n>0)
                    {
                        image1.setImageResource(abc[--n]);
                    }
                    else
                    {
                        n = abc.length-1;
                        image1.setImageResource(abc[n]);
                    }
                }
            });

        }
        if(type.equals("shapes"))
        {
            image1.setImageResource(shapes[n]);

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if(n<shapes.length-1)
                    {
                        image1.setImageResource(shapes[++n]);
                    }
                    else
                    {
                        n=0;
                        image1.setImageResource(shapes[n]);
                    }

                }
            });

            previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (n> 0)
                    {
                        image1.setImageResource(shapes[--n]);
                        Toast.makeText(getApplicationContext(),""+n,Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        n = shapes.length-1;
                        image1.setImageResource(shapes[n]);
                        Toast.makeText(getApplicationContext(),""+n,Toast.LENGTH_LONG).show();
                    }
                }
            });

        }

        if(type.equals("colours"))
        {
            image1.setImageResource(colours[n]);

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    if(n<colours.length-1)
                    {
                        image1.setImageResource(colours[++n]);
                    }
                    else
                    {
                        n=0;
                        image1.setImageResource(colours[n]);
                    }

                }
            });

            previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (n> 0)
                    {
                        image1.setImageResource(colours[--n]);
                    }
                    else
                    {
                        n = colours.length-1;
                        image1.setImageResource(colours[n]);
                    }
                }
            });

        }

        if(type.equals("flowers"))
        {
            image1.setImageResource(flowers[n]);

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    if(n<flowers.length-1)
                    {
                        image1.setImageResource(flowers[++n]);
                    }
                    else
                    {
                        n=0;
                        image1.setImageResource(flowers[n]);
                    }

                }
            });

            previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (n> 0)
                    {
                        image1.setImageResource(flowers[--n]);
                    }
                    else
                    {
                        n = flowers.length-1;
                        image1.setImageResource(flowers[n]);
                    }
                }
            });

        }

        if(type.equals("vegetables"))
        {
            image1.setImageResource(vegs[n]);

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    if(n<vegs.length-1)
                    {
                        image1.setImageResource(vegs[++n]);
                    }
                    else
                    {
                        n=0;
                        image1.setImageResource(vegs[n]);
                    }

                }
            });

            previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (n> 0)
                    {
                        image1.setImageResource(vegs[--n]);
                    }
                    else
                    {
                        n = vegs.length-1;
                        image1.setImageResource(vegs[n]);
                    }
                }
            });

        }
        if(type.equals("fruits"))
        {
            image1.setImageResource(fruits[n]);

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    if(n<fruits.length-1)
                    {
                        image1.setImageResource(fruits[++n]);
                    }
                    else
                    {
                        n=0;
                        image1.setImageResource(fruits[n]);
                    }

                }
            });

            previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (n>0)
                    {
                        image1.setImageResource(fruits[--n]);
                    }
                    else
                    {
                        n = fruits.length-1;
                        image1.setImageResource(fruits[n]);
                    }
                }
            });
        }
    }
}
